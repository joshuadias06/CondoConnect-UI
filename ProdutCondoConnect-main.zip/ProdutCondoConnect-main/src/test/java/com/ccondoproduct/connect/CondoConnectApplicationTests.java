package com.ccondoproduct.connect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CondoConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
