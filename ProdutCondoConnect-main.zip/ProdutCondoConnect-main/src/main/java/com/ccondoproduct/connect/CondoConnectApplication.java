package com.ccondoproduct.connect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CondoConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CondoConnectApplication.class, args);
	}

}
