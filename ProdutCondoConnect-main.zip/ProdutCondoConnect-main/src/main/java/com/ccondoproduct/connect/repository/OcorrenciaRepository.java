package com.ccondoproduct.connect.repository;

import com.ccondoproduct.connect.model.Ocorrencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OcorrenciaRepository extends JpaRepository<Ocorrencia, Long> {}
