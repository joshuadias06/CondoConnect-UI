package com.ccondoproduct.connect.model;

public enum StatusOcorrencia {
    PENDENTE, EM_ANDAMENTO, RESOLVIDO;
}
