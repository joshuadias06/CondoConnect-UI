package com.ccondoproduct.connect.repository;

import com.ccondoproduct.connect.model.Localizacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalizacaoRepository extends JpaRepository<Localizacao, Long> {
}
