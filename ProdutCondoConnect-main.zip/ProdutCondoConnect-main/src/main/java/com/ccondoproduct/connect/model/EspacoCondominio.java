package com.ccondoproduct.connect.model;

public enum EspacoCondominio {
    SALAO_DE_FESTAS,
    PISCINA,
    CHURRASQUEIRA,
    QUADRA,
    ACADEMIA,
    ESPACO_GOURMET
}
